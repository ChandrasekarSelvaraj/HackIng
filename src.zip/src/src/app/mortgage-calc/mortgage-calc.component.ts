import { Component, OnInit } from '@angular/core';
import { Mortgage } from './mortgage';

@Component({
  selector: 'app-mortgage-calc',
  templateUrl: './mortgage-calc.component.html',
  styleUrls: ['./mortgage-calc.component.scss']
})
export class MortgageCalcComponent implements OnInit {

  submitted: boolean = false;

  emi: number;

  model = new Mortgage(10000, 2, 10000, 8000);

  constructor() { }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
    this.emi = 1000;
  }

}
