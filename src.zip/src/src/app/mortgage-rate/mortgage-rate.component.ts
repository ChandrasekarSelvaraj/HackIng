import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mortgage-rate',
  templateUrl: './mortgage-rate.component.html',
  styleUrls: ['./mortgage-rate.component.scss']
})
export class MortgageRateComponent implements OnInit {


  products: any[] = [
    { name: "1 year", fixedRatePeriod:1, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "2 year", fixedRatePeriod:1, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "3 year", fixedRatePeriod:1, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "5 year", fixedRatePeriod:1, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "6 year", fixedRatePeriod:1, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "10 year", fixedRatePeriod:2, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "15 year", fixedRatePeriod:3, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "20 year", fixedRatePeriod:4, rate: '1.88', lastUpdated:"Oct 2018" },
    { name: "30 year", fixedRatePeriod:5, rate: '1.88', lastUpdated:"Oct 2018" },
  ];

  constructor() { }

  ngOnInit() {
  }

}
