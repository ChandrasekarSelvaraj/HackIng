import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MortgageRateComponent } from './mortgage-rate/mortgage-rate.component';
import { MortgageCalcComponent } from './mortgage-calc/mortgage-calc.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path:"rate",
    component:MortgageRateComponent
  },
  {
    path:"emi",
    component:MortgageCalcComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
